﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    public float speed;
    public int coin;
    Rigidbody PlayerRigidbody;
    public Text txt_coin;

    private int levels = 0;
    // Start is called before the first frame update
    void Start()
    {
        PlayerRigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
        PlayerRigidbody.AddForce(movement * speed * Time.deltaTime);

        if (coin == 5 && levels == 0)
        {
            SceneManager.LoadScene("GamePlay_Level2");
            levels++;
        }

        else if (coin == 5 && levels == 1)
        {
            SceneManager.LoadScene("GameWin");
            levels = 0;
        }
    }

    public void OnCollisionEnter(Collision collision)
    {
        if (collision.other.tag == "coin")
        {
            coin ++;
            Destroy(collision.gameObject);
            
            txt_coin.text = "Coins Collected = " + coin;
        }

        if (collision.other.tag == "hazard")
        {
            SceneManager.LoadScene("GameLose");
            levels = 0;
        }
    }
}
